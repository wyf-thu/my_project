// 用户
class User {
  constructor (id) {
    this.id = id
    this.name = '昵名用户'
  }
}
module.exports = User
